# 30-Day Social Media Marketing Plan

## Week 1: Foundation & Awareness

| Day | Platform | Format | Topic | CTA |
|---|---|---|---|---|
| 1 | Instagram | Carousel | Meet the brand: our story and mission | Follow for more |
| 2 | LinkedIn | Text post | Problem we solve and who it's for | Comment your biggest challenge |
| 3 | TikTok | Short video | Behind-the-scenes: a day in the life | Follow + like |
| 4 | Facebook | Poll | What content do you want to see? | Vote in the poll |
| 5 | Instagram | Reel | 3 quick tips in your niche | Save this post |
| 6 | X/Twitter | Thread | Myths vs facts in our industry | Retweet to share |
| 7 | All | Recap + Stories | Week 1 recap and audience Q&A box | Send us your questions |

## Week 2: Engagement & Education

| Day | Platform | Format | Topic | CTA |
|---|---|---|---|---|
| 8 | Instagram | Carousel | Beginner's guide: step-by-step | Save + share |
| 9 | LinkedIn | Article | Industry trends to watch this year | Share your take |
| 10 | TikTok | Tutorial video | How-to: solve one common problem fast | Follow for part 2 |
| 11 | Facebook | Live session | Live Q&A with the founder/team | Join the live |
| 12 | Instagram | Reel | Before/after or transformation | Tag a friend |
| 13 | X/Twitter | Poll + thread | This or that: community poll | Vote and reply |
| 14 | All | Recap + Stories | Week 2 recap, best-performing post repost | Tell us your favorite |

## Week 3: Social Proof & Conversion

| Day | Platform | Format | Topic | CTA |
|---|---|---|---|---|
| 15 | Instagram | Carousel | Customer story / case study | Read the full story (link in bio) |
| 16 | LinkedIn | Testimonial post | Client result with numbers | Book a call |
| 17 | TikTok | Short video | Unboxing / product demo | Shop the link |
| 18 | Facebook | Image post | Customer reviews roundup | Leave your review |
| 19 | Instagram | Reel | FAQ: top 3 questions answered | DM us your question |
| 20 | X/Twitter | Thread | Results thread: what worked and why | Retweet |
| 21 | All | Promo + Stories | Limited-time offer announcement | Claim the offer |

## Week 4: Community & Scale

| Day | Platform | Format | Topic | CTA |
|---|---|---|---|---|
| 22 | Instagram | UGC repost | Feature a customer's content | Tag us to be featured |
| 23 | LinkedIn | Text post | Lessons learned building this | Share your lesson |
| 24 | TikTok | Trend/Challenge | Join a trending sound with a brand twist | Duet or stitch us |
| 25 | Facebook | Group post | Start a community discussion thread | Join the group |
| 26 | Instagram | Carousel | Top 5 resources / tools roundup | Save + share |
| 27 | X/Twitter | Spaces/Thread | Community AMA | Ask your question |
| 28 | Instagram | Giveaway | Giveaway: follow, like, tag 2 friends | Enter now |
| 29 | LinkedIn | Article | 30-day results and key learnings | Subscribe/follow |
| 30 | All | Recap + Stories | Thank-you post and what's next | Tell us what you want next |

