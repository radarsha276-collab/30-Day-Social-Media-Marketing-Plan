# Strategy Worksheet

## Goals (pick 1-3, make them measurable)
- Grow followers by ___% in 30 days
- Reach ___ accounts / ___ impressions
- Generate ___ leads / sales / sign-ups

## Target audience
- Who: ___  | Pain points: ___  | Where they spend time: ___

## Content pillars
| Pillar | Share of posts | Examples |
|---|---|---|
| Educational | 40% | Tips, tutorials, guides |
| Engagement | 25% | Polls, Q&A, challenges |
| Social proof | 20% | Reviews, case studies, UGC |
| Promotional | 15% | Offers, launches, demos |

## Cadence
- Instagram: 5/week | LinkedIn: 3/week | TikTok: 4/week | Facebook: 3/week | X: 5/week
- Best times: check platform analytics after week 1 and adjust.

## Weekly routine
- Mon: schedule the week's posts | Daily: 15 min replying to comments/DMs | Fri: review KPIs
