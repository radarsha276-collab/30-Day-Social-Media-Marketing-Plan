# Post Templates

## Hook formulas
- "Stop doing [common mistake]. Do this instead."
- "[Number] things I wish I knew before [topic]."
- "Most people think [myth]. Here's the truth."
- "How I [result] in [timeframe] (without [pain point])."

## Carousel
Slide 1: bold hook | Slides 2-7: one idea each | Last slide: recap + CTA

## Short video (15-30s)
0-3s hook | 3-20s value | last 5s CTA

## LinkedIn post
Line 1: hook | short paragraphs | lesson or takeaway | question to drive comments

## Testimonial
Challenge -> What we did -> Result (with number) -> CTA
